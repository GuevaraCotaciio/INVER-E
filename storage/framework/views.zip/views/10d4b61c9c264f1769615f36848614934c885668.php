
  <!-- ======= Header ======= -->
  <?php echo $__env->make('Templates.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Header -->



   <!-- ======= Content  ======= -->
  <main class="col-12 ps-1" style="background-color: #e8edf4;">

    <!-- Tirulos modulos-->
    

    <section class="section pb-5">
      <div class="row col-12 m-0">

        <!-- ======= Contenedor items ======= -->
        <div class="col-12 pt-4">

          <!-- Separador linea de productos  -->
          

          <div class="row col-12 m-0 p-0 align-items-center justify-content-center">

            <div class="col-sm-2 bg-white " >
               <div class="card-body">
                  <a class=" nav-link" href="<?php echo e(route('clientes_general')); ?>"><h5 class="card-title">Clientes</h5></a>

                  <div class="d-flex align-items-center">
                    <div style="border-radius: 50%!important; background-color:#e0f8e9; width: 64px; height: 64px; font-size: 32px;" class="d-flex align-items-center justify-content-center">
                      <a href="<?php echo e(route('clientes_general')); ?>"><i class="bi bi-person-check" style="color: #2eca6a;"></i></a>
                    </div>
                    <div class="ps-1">
                      <h6>Cantidad</h6>
                      <span class="text-success small pt-1 fw-bold"><?php echo e($CantidadClientes); ?></span> <span class="text-muted small pt-2 ps-1"> clientes</span>

                    </div>
                  </div>
               </div>
            </div>

            <div class="col-sm-2 bg-white ms-4" >
               <div class="card-body">
                  <a class=" nav-link" href="<?php echo e(route('pedidos.general')); ?>"><h5 class="card-title">Pedidos</h5></a>
                  <div class="d-flex align-items-center">
                    <div  style="border-radius: 50%!important; background-color:#e0f8e9; width: 64px; height: 64px; font-size: 32px;" class=" d-flex align-items-center justify-content-center">
                      <a href="<?php echo e(route('pedidos.general')); ?>"><i class="bi bi-clipboard-check" style="color: #2eca6a;"></i></a>
                    </div>
                    <div class="ps-1">
                      <h6>Realizados</h6>
                      <span class="text-success small pt-1 fw-bold">9</span> <span class="text-muted small pt-2 ps-1">pedidos</span>
                    </div>
                  </div>
               </div>
            </div>


            <div class="col-sm-2 bg-white ms-4" >
               <div class="card-body">
                  <a class=" nav-link" href="<?php echo e(route('productos.general')); ?>"><h5 class="card-title">Productos</h5></a>
                  <div class="d-flex align-items-center">
                    <div style="border-radius: 50%!important; background-color:#e0f8e9; width: 64px; height: 64px; font-size: 32px;" class=" d-flex align-items-center justify-content-center">
                      <a href="<?php echo e(route('productos.general')); ?>"><i class="bi bi-cart4" style="color: #2eca6a;"></i></a>
                    </div>
                    <div class="ps-1">
                      <h6>Disponibles</h6>
                      <span class="text-success small pt-1  fw-bold"><?php echo e($CantidadProductos); ?></span> <span class="text-muted small pt-2 ps-1"> Chorizos</span>
                    </div>
                  </div>
               </div>
            </div>


            <div class="col-sm-2 bg-white ms-4" >
               <div class="card-body">
                  <a class=" nav-link" href="<?php echo e(route('informes.general')); ?>"><h5 class="card-title">Informes</h5></a>
                  <div class="d-flex align-items-center">
                    <div style="border-radius: 50%!important; background-color:#e0f8e9; width: 64px; height: 64px; font-size: 32px;" class=" d-flex align-items-center justify-content-center">
                    <a href="<?php echo e(route('informes.general')); ?>"><i class="bi bi-graph-up-arrow " style="color: #2eca6a;"></i></a>
                    </div>
                    <div class="ps-1">
                      <h6>Tipos</h6>


                      <span class="text-success small pt-1 fw-bold">xlxs <i class="bi bi-file-earmark-spreadsheet"></i></span>
                      <span class="text-success small pt-1 fw-bold">pdf <i class="bi bi-file-earmark-pdf"></i></span>
                    </div>
                  </div>
               </div>
            </div>


            <div class="col-sm-2 bg-white ms-4" >
               <div class="card-body">
                  <a class=" nav-link" href="<?php echo e(route('usuarios.general')); ?>"><h5 class="card-title">Usuarios</h5></a>
                  <div class="d-flex align-items-center">
                    <div style="border-radius: 50%!important; background-color:#e0f8e9; width: 64px; height: 64px; font-size: 32px;" class=" d-flex align-items-center justify-content-center">
                      <a href="<?php echo e(route('usuarios.general')); ?>"><i class="bi bi-people" style="color: #2eca6a;"></i></a>
                    </div>
                    <div class="ps-1">
                      <h6>Cantidad</h6>
                      <span class="text-success small pt-1 fw-bold"><?php echo e($CantidadUsuarios); ?></span> <span class="text-muted small pt-2 ps-1">operarios</span>
                    </div>
                  </div>
               </div>
            </div>

          </div>
        </div>





        <div class="row col-lg-12 mt-5 m-0 "> <hr>

          <div class="col-lg-6">
            <div class="row col-lg-12 pb-2 align-items-center justify-content-center">
              <!-- Separador linea de productos  -->
              <div class="card-body m-0">
                <h5 class="card-title ps-1">Productos proximos a agotarse </h5>
              </div>

              <?php $__currentLoopData = $Productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <!-- Producto 1 -->
              <div class="col-3 bg-white ">

                <div class="card" style="border: 0px; height: 260px;">

                  <div class="card-head" style="width: 130px; height: 80px;">
                    <img src="<?php echo e(asset('images/comino.png')); ?>" class="d-block w-100 pt-2" alt="via1">
                  </div>

                  <div class="card-body">
                    <h5 class="card-title"> <?php echo e($producto->nombre); ?></h5>
                    <p class="card-text">Vence el día <?php echo e($producto->fecha_vencimiento); ?></p>
                    <a href="#" class="btn btn-primary btn-sm">Verificar</a>
                  </div>
                </div>
              </div>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
          </div>

          <div class="col-lg-6">
            <div class="row col-lg-12 pb-2 align-items-center justify-content-center" >
              <!-- Separador linea de productoss -->
              <div class="card-body m-0">
                <h5 class="card-title ps-1">Pedidos poximos a entregar</h5>
              </div>

              <!-- pedido 1 -->
              <div class="col-3 ms-3 bg-white ">

                <div class="card" style="border: 0px; height: 260px;">

                  <div class="card-head" style="width: 130px; height: 80px;">
                    <img src="<?php echo e(asset('images/comino.png')); ?>" class="d-block w-100 pt-2" alt="via1">
                  </div>
                  <div class="card-body">
                    <h5 class="card-title">Pedido 1</h5>
                    <p class="card-text">para: $cliente</p>
                    <a href="#" class="btn btn-primary">Revisar</a>
                  </div>
                </div>
              </div>

              <!-- pedido 2 -->
              <div class="col-3 ms-5 bg-white ">

                <div class="card" style="border: 0px; height: 260px;">

                  <div class="card-head" style="width: 130px; height: 80px;">
                    <img src="<?php echo e(asset('images/comino.png')); ?>" class="d-block w-100 pt-2" alt="via1">
                  </div>
                  <div class="card-body">
                    <h5 class="card-title">pedido 2</h5>
                    <p class="card-text">para: $cliente</p>
                    <a href="#" class="btn btn-primary">Revisar</a>
                  </div>
                </div>
              </div>

              <!-- pedido 3 -->
              <div class="col-3 ms-5 bg-white ">
                <div class="card" style="border: 0px; height: 260px;">

                  <div class="card-head" style="width: 130px; height: 80px;">
                    <img src="<?php echo e(asset('images/comino.png')); ?>" class="d-block w-100 pt-2" alt="via1">
                  </div>
                  <div class="card-body">
                    <h5 class="card-title">pedido 3</h5>
                    <p class="card-text">para: $cliente</p>
                    <a href="#" class="btn btn-primary">Revisar</a>
                  </div>
                </div>
              </div>

            </div>

          </div>

        </div><!-- End new Card -->

            <!-- Separador linea de productoss -->
            

            <!-- seccion Recent Sales -->
            

            <!-- Separador linea de productos -->
            

            <!-- Top Selling -->
            



      </div>
    </section>
  </main><!-- End Conten -->


  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\Inver-E\resources\views/home.blade.php ENDPATH**/ ?>