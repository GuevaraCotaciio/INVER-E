
<head>
    <!--Estilos--><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <!--Icons--><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
</head>

<!-- Footer -->
<footer class="container-fluid pt-4 bg-dark text-white"  > <!--style="background-color: #eee;"-->
        <div class="row text-center">

            <div class="col-md-12">
                <a href="https://www.facebook.com/" ><img src="<?php echo e(asset('images/facebook.png')); ?>" class="img-fluid" width="40px" title="Facebook"></a>
                <a href="https://www.instagram.com/"><img src="<?php echo e(asset('images/instagram.png')); ?>" class="img-fluid" width="40px" title="Instagram"></a>
                <a href="https://www.whatsapp.com/"><img src="<?php echo e(asset('images/whatsapp.png')); ?>" class="img-fluid" width="40px" title="Whatsapp"></a>
                <p class="mt-3">Copyright © 2022 Inver-E <br> Todos los derechos reservados.</p>
            </div>

        </div>
    </footer>
<?php /**PATH C:\xampp\htdocs\Inver-E\resources\views/Templates/footer.blade.php ENDPATH**/ ?>