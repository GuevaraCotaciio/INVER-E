<head>
    <title>Inver-E / Productos</title>
</head>

  <!-- ======= Header ======= -->
  <?php echo $__env->make('Templates.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Header -->


   <!-- ======= Content  ======= -->
    <main class="col-12 ps-1" style="background-color: #e8edf4;">

        <!-- Tirulos modulos-->
        <div class="pagetitle ps-4">
          <h1>Productos</h1>
            <nav>
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                <li class="breadcrumb-item active">Productos</li>
              </ol>
            </nav>
        </div>

        <section class="section dashboard pb-5">
            <div class="row col-12">


                <div class="col-lg-12"> <!-- ========= OPCIONES  ========= -->

                    <div class="row col-sm-12 pt-3  align-items-center justify-content-center">

                        <div class="col-sm-3 bg-white " >
                           <div class="card-body">
                              <a class=" nav-link" href="<?php echo e(route('productos.create')); ?>"><h5 class="card-title">Nuevo Producto</h5></a>

                              <div class="d-flex align-items-center">
                                <div style="border-radius: 50%!important; background-color:#e0f8e9; width: 64px; height: 64px; font-size: 32px;" class=" d-flex align-items-center justify-content-center">
                                  <a href="<?php echo e(route('productos.create')); ?>"><i class="bi bi-person-check" style="color: #2eca6a;"></i></a>
                                </div>
                                <div class="ps-2">
                                  <h6>145</h6>
                                  <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span>
                                </div>
                              </div>
                           </div>
                        </div>

                        <div class="col-sm-3 bg-white ms-4" >
                           <div class="card-body">
                              <a class=" nav-link" href="#"><h5 class="card-title">Informes Productos</h5></a>
                              <div class="d-flex align-items-center">
                                <div  style="border-radius: 50%!important; background-color:#e0f8e9; width: 64px; height: 64px; font-size: 32px;" class=" d-flex align-items-center justify-content-center">
                                  <a href="#"><i class="bi bi-clipboard-check" style="color: #2eca6a;"></i></a>
                                </div>
                                <div class="ps-2">
                                  <h6>145</h6>
                                  <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span>
                                </div>
                              </div>
                           </div>
                        </div>

                        <div class="col-sm-3 bg-white ms-4" >
                           <div class="card-body">
                              <a class=" nav-link" href="<?php echo e(route('productos.ver')); ?>"><h5 class="card-title">Todos los productos</h5></a>
                              <div class="d-flex align-items-center">
                                <div style="border-radius: 50%!important; background-color:#e0f8e9; width: 64px; height: 64px; font-size: 32px;" class=" d-flex align-items-center justify-content-center">
                                  <a href="<?php echo e(route('productos.ver')); ?>"><i class="bi bi-cart4" style="color: #2eca6a;"></i></a>
                                </div>
                                <div class="ps-2">
                                  <h6>145</h6>
                                  <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span>
                                </div>
                              </div>
                           </div>
                        </div>

                    </div>

                </div>


                <div class="col-lg-12 ps-4 pe-1">

                    <div class="card-body ps-0">   <!-- Separador linea de productoss -->
                        <h5 class="card-title pt-4 ">Lista de productos</h5>
                        <div id="reportsChart"></div>
                    </div>


                    <div class="col-12  pb-2">     <!-- productos disponibles -->
                        <div class="card recent-sales overflow-auto">

                            <div class="filter">
                                <a class="ps-2" href="#" data-bs-toggle="dropdown"> <i class="bi bi-three-dots" title="Filtro"></i></a>
                                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                    <li class="dropdown-header text-start">
                                    <h6>Filtros</h6>
                                    </li>

                                    <li><a class="dropdown-item" href="#">Hoy</a></li>
                                    <li><a class="dropdown-item" href="#">Esta semana</a></li>
                                    <li><a class="dropdown-item" href="#">Este mes</a></li>
                                </ul>
                            </div>

                            <div class="card-body">
                                <h5 class="card-title">Productos Disponibles</h5>

                                <table class="table table-borderless datatable" >
                                    <thead>
                                        <tr>
                                            <th scope="col" class="border-bottom border-danger">ID</th>
                                            <th scope="col" class="border-bottom border-danger">Nombre</th>
                                            <th scope="col" class="border-bottom border-danger">Estado</th>
                                            <th scope="col" class="border-bottom border-danger">Calibre</th>
                                            <th scope="col" class="border-bottom border-danger">Clasificación</th>
                                            <th scope="col" class="border-bottom border-danger">Cantidad</th>
                                            <th scope="col" class="border-bottom border-danger">Duración</th>
                                            <th scope="col" class="border-bottom border-danger">Vencimiento</th>
                                            <th scope="col" class="border-bottom border-danger">Peso unitario</th>
                                            <th scope="col" class="border-bottom border-danger">Valor unitario</th>
                                            <th scope="col" class="border-bottom border-danger">Valor comercial</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(count($ProductosDisponibles)<=0): ?>
                                          <tr>
                                            <td colspan="10" class="text-danger"> No hay registros para el nombre solicitado</td>
                                          </tr>
                                        <?php else: ?>
                                          <?php $__currentLoopData = $ProductosDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productoDisp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr scope="row">
                                              <td class="border-bottom"><?php echo e($productoDisp->id); ?></td>
                                              <td class="border-bottom"><?php echo e($productoDisp->nombre); ?></td>
                                              <td class="border-bottom"><?php echo e($productoDisp->estado_producto); ?></td>
                                              <td class="border-bottom"><?php echo e($productoDisp->calibre_producto); ?></td>
                                              <td class="border-bottom"><?php echo e($productoDisp->clasificacion_producto); ?></td>
                                              <td class="border-bottom"><?php echo e($productoDisp->cantidad); ?></td>
                                              <td class="border-bottom"><?php echo e($productoDisp->duracion); ?></td>
                                              <td class="border-bottom"><?php echo e($productoDisp->fecha_vencimiento); ?></td>
                                              <td class="border-bottom"><?php echo e($productoDisp->peso_unitario); ?></td>
                                              <td class="border-bottom"><?php echo e($productoDisp->valor_venta); ?></td>
                                              <td class="border-bottom"><?php echo e($productoDisp->valor_compra); ?></td>
                                            </tr >
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>

                                <div class=" row col-12 mt-3">  <!-- paginación -->
                                    <div class="col-5"></div>
                                    <div class="col-2 ps-5"> <?php echo e($ProductosDisponibles->links()); ?></div>
                                    <div class="col-5"></div>
                                </div>

                            </div>

                        </div>

                    </div>


                    <div class="col-12 pb-2">          <!-- productos proximos a Vencer -->
                        <div class="card top-selling overflow-auto">

                          <div class="filter">
                            <a class="ps-2" href="#" data-bs-toggle="dropdown"> <i class="bi bi-three-dots" title="Filtro"></i></a>
                            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                              <li class="dropdown-header text-start">
                                <h6>Filtros</h6>
                              </li>

                              <li><a class="dropdown-item" href="#">Hoy</a></li>
                              <li><a class="dropdown-item" href="#">Esta semana</a></li>
                              <li><a class="dropdown-item" href="#">Este mes</a></li>
                            </ul>
                          </div>

                          <div class="card-body pb-0">
                            <h5 class="card-title">Productos proximos a vencer</h5>

                            <table class="table table-borderless">
                              <thead>
                                  <tr>
                                      <th scope="col" class="border-bottom border-danger">ID</th>
                                      <th scope="col" class="border-bottom border-danger">Nombre</th>
                                      <th scope="col" class="border-bottom border-danger">Estado</th>
                                      <th scope="col" class="border-bottom border-danger">Calibre</th>
                                      <th scope="col" class="border-bottom border-danger">Clasificación</th>
                                      <th scope="col" class="border-bottom border-danger">Cantidad</th>
                                      <th scope="col" class="border-bottom border-danger">Duración</th>
                                      <th scope="col" class="border-bottom border-danger">Vencimiento</th>
                                      <th scope="col" class="border-bottom border-danger">Peso unitario</th>
                                      <th scope="col" class="border-bottom border-danger">Valor unitario</th>
                                      <th scope="col" class="border-bottom border-danger">Valor comercial</th>
                                  </tr>
                              </thead>
                              <tbody>
                                  <?php if(count($ProductosPorVencer)<=0): ?>
                                    <tr>
                                      <td colspan="10" class="text-danger"> No hay registros para mostrar</td>
                                    </tr>
                                  <?php else: ?>
                                    <?php $__currentLoopData = $ProductosPorVencer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productoVencer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                        <td class="border-bottom"><?php echo e($productoVencer->id); ?></td>
                                        <td class="border-bottom"><?php echo e($productoVencer->nombre); ?></td>
                                        <td class="border-bottom"><?php echo e($productoVencer->estado_producto); ?></td>
                                        <td class="border-bottom"><?php echo e($productoVencer->calibre_producto); ?></td>
                                        <td class="border-bottom"><?php echo e($productoVencer->clasificacion_producto); ?></td>
                                        <td class="border-bottom"><?php echo e($productoVencer->cantidad); ?></td>
                                        <td class="border-bottom"><?php echo e($productoVencer->duracion); ?></td>
                                        <td class="border-bottom"><?php echo e($productoVencer->fecha_vencimiento); ?></td>
                                        <td class="border-bottom"><?php echo e($productoVencer->peso_unitario); ?></td>
                                        <td class="border-bottom"><?php echo e($productoVencer->valor_venta); ?></td>
                                        <td class="border-bottom"><?php echo e($productoVencer->valor_compra); ?></td>
                                      </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <?php endif; ?>
                              </tbody>
                            </table>

                            <div class=" row col-12 mt-3">  <!-- paginación -->
                              <div class="col-5"></div>
                              <div class="col-2 ps-5"> <?php echo e($ProductosVencidos->links()); ?></div>
                              <div class="col-5"></div>
                            </div>

                          </div>

                        </div>
                    </div>


                    <div class="col-12 ">          <!-- productos Vencidos -->
                      <div class="card top-selling overflow-auto">

                        <div class="filter">
                          <a class="ps-2" href="#" data-bs-toggle="dropdown"> <i class="bi bi-three-dots" title="Filtro"></i></a>
                          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                            <li class="dropdown-header text-start">
                              <h6>Filtros</h6>
                            </li>

                            <li><a class="dropdown-item" href="#">Hoy</a></li>
                            <li><a class="dropdown-item" href="#">Esta semana</a></li>
                            <li><a class="dropdown-item" href="#">Este mes</a></li>
                          </ul>
                        </div>

                        <div class="card-body pb-0">
                          <h5 class="card-title">Productos Vencidos</h5>

                          <table class="table table-borderless">
                            <thead>
                                <tr>
                                    <th scope="col" class="border-bottom border-danger">ID</th>
                                    <th scope="col" class="border-bottom border-danger">Nombre</th>
                                    <th scope="col" class="border-bottom border-danger">Estado</th>
                                    <th scope="col" class="border-bottom border-danger">Calibre</th>
                                    <th scope="col" class="border-bottom border-danger">Clasificación</th>
                                    <th scope="col" class="border-bottom border-danger">Cantidad</th>
                                    <th scope="col" class="border-bottom border-danger">Duración</th>
                                    <th scope="col" class="border-bottom border-danger">Vencimiento</th>
                                    <th scope="col" class="border-bottom border-danger">Peso unitario</th>
                                    <th scope="col" class="border-bottom border-danger">Valor unitario</th>
                                    <th scope="col" class="border-bottom border-danger">Valor comercial</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($ProductosVencidos)<=0): ?>
                                  <tr>
                                    <td colspan="10" class="text-danger"> No hay registros para mostrar</td>
                                  </tr>
                                <?php else: ?>
                                  <?php $__currentLoopData = $ProductosVencidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productoVenc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                      <td class="border-bottom"><?php echo e($productoVenc->id); ?></td>
                                      <td class="border-bottom"><?php echo e($productoVenc->nombre); ?></td>
                                      <td class="border-bottom"><?php echo e($productoVenc->estado_producto); ?></td>
                                      <td class="border-bottom"><?php echo e($productoVenc->calibre_producto); ?></td>
                                      <td class="border-bottom"><?php echo e($productoVenc->clasificacion_producto); ?></td>
                                      <td class="border-bottom"><?php echo e($productoVenc->cantidad); ?></td>
                                      <td class="border-bottom"><?php echo e($productoVenc->duracion); ?></td>
                                      <td class="border-bottom"><?php echo e($productoVenc->fecha_vencimiento); ?></td>
                                      <td class="border-bottom"><?php echo e($productoVenc->peso_unitario); ?></td>
                                      <td class="border-bottom"><?php echo e($productoVenc->valor_venta); ?></td>
                                      <td class="border-bottom"><?php echo e($productoVenc->valor_compra); ?></td>
                                    </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                          </table>

                          <div class=" row col-12 mt-3">  <!-- paginación -->
                            <div class="col-5"></div>
                            <div class="col-2 ps-5"> <?php echo e($ProductosVencidos->links()); ?></div>
                            <div class="col-5"></div>
                          </div>

                        </div>

                      </div>
                    </div>

                </div>


            </div>
        </section>
    </main><!-- End Conten -->

  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\Inver-E\resources\views/productos_general.blade.php ENDPATH**/ ?>