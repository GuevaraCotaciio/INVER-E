<head>
<title>Inver-E / Usuarios</title>
</head>
  <!-- ======= Header ======= -->
  <?php echo $__env->make('Templates.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Header -->
  
  
  <!-- ======= Contendor Principal  ======= -->
  <main class="col-12 ps-1" style="background-color: #e8edf4;">
    
    <!-- Tirulos modulos-->
    <div class="pagetitle ps-4"> 
      <h1>Usuarios</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
          <li class="breadcrumb-item active">Usuarios</li>
        </ol>
      </nav>
    </div>
    
    <!-- ========= OPCIONES  ========= -->
    <div class="col-lg-12">
      
      <div class="card-body"></div>
      
      <div class="row col-sm-12   align-items-center justify-content-center">
  
        <div class="col-sm-3 bg-white " >
           <div class="card-body">
              <a class=" nav-link" href="<?php echo e(route('clientes_general')); ?>"><h5 class="card-title">Nuevo usuario</h5></a>
  
              <div class="d-flex align-items-center">
                <div style="border-radius: 50%!important; background-color:#e0f8e9; width: 64px; height: 64px; font-size: 32px;" class=" d-flex align-items-center justify-content-center">
                  <a href="<?php echo e(route('clientes_general')); ?>"><i class="bi bi-person-check" style="color: #2eca6a;"></i></a>
                </div>
                <div class="ps-2">
                  <h6>145</h6>
                  <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span>
  
                </div>
              </div>
           </div>
        </div>
  
        <div class="col-sm-3 bg-white ms-4" >
           <div class="card-body">
              <a class=" nav-link" href="<?php echo e(route('pedidos')); ?>"><h5 class="card-title">Actualizar usuario</h5></a>
              <div class="d-flex align-items-center">
                <div  style="border-radius: 50%!important; background-color:#e0f8e9; width: 64px; height: 64px; font-size: 32px;" class=" d-flex align-items-center justify-content-center">
                  <a href="<?php echo e(route('pedidos')); ?>"><i class="bi bi-clipboard-check" style="color: #2eca6a;"></i></a>
                </div>
                <div class="ps-2">
                  <h6>145</h6>
                  <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span>
                </div>
              </div>
           </div>
        </div>
  
        <div class="col-sm-3 bg-white ms-4" >
           <div class="card-body">
              <a class=" nav-link" href="<?php echo e(route('productos_general')); ?>"><h5 class="card-title">Elimina usuarios</h5></a>
              <div class="d-flex align-items-center">
                <div style="border-radius: 50%!important; background-color:#e0f8e9; width: 64px; height: 64px; font-size: 32px;" class=" d-flex align-items-center justify-content-center">
                  <a href="<?php echo e(route('productos_general')); ?>"><i class="bi bi-cart4" style="color: #2eca6a;"></i></a>
                </div>
                <div class="ps-2">
                  <h6>145</h6>
                  <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span>
                </div>
              </div>
           </div>
        </div>
  
  
      </div>
    </div> 
    
    <!-- ========= Contenedor tablas ========= -->
    <section class=" mt-5">
      <div class="row col-lg-12 align-items-center justify-content-center">
        
        <!-- ========= Titulos y buscador ========= -->
        <div class="row col-lg-12 p-3 align-items-center justify-content-center">
            <div class="row col-12 p-0">

                <div class="col-7">
                  
                  <div class="row"> 
                    <h5 class=" pt-2 ps-2">Lista completa de Clientes </h5>
                  </div>

                </div>
                <div class="col-4 ps-1 pt-1 pe-0">
                    <input name="Buscar_cliente " type="text" class="form-control p-2 " id="Buscar_cliente" placeholder="Primer Nombre">
                </div>
                <div class="col-1 ps-1 p-0"> 
                  <a class="btn  btn-info btn-lg"> <i class="bi bi-search"></i> Buscar </a>
                </div>
            </div>
        </div>


        <!-- ========= Tablas ========= -->
        <div class="row col-lg-12 ps-2 pe-0 pb-3">

            <!-- ========= lista ========= -->
            <div class="col-7 pe-1 pb-3">
                <div class="card recent-sales overflow-auto">

                    <div class="filter">
                      <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                      <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                        <li class="dropdown-header text-start">
                          <h6>Filter</h6>
                        </li>
    
                        <li><a class="dropdown-item" href="#">Today</a></li>
                        <li><a class="dropdown-item" href="#">This Month</a></li>
                        <li><a class="dropdown-item" href="#">This Year</a></li>
                      </ul>
                    </div>
                    
                    <div class="card-body">
                      <h5 class="card-title">Recent Sales <span>| Today</span></h5>
    
                      <table class="table table-borderless datatable">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Customer</th>
                            <th scope="col">Product</th>
                            <th scope="col">Price</th>
                            <th scope="col">Status</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <th scope="row"><a href="#">#2457</a></th>
                            <td>Brandon Jacob</td>
                            <td><a href="#" class="text-primary">At praesentium minu</a></td>
                            <td>$64</td>
                            <td><span class="badge bg-success">Approved</span></td>
                          </tr>
                          <tr>
                            <th scope="row"><a href="#">#2147</a></th>
                            <td>Bridie Kessler</td>
                            <td><a href="#" class="text-primary">Blanditiis dolor omnis similique</a></td>
                            <td>$47</td>
                            <td><span class="badge bg-warning">Pending</span></td>
                          </tr>
                          <tr>
                            <th scope="row"><a href="#">#2049</a></th>
                            <td>Ashleigh Langosh</td>
                            <td><a href="#" class="text-primary">At recusandae consectetur</a></td>
                            <td>$147</td>
                            <td><span class="badge bg-success">Approved</span></td>
                          </tr>
                          <tr>
                            <th scope="row"><a href="#">#2644</a></th>
                            <td>Angus Grady</td>
                            <td><a href="#" class="text-primar">Ut voluptatem id earum et</a></td>
                            <td>$67</td>
                            <td><span class="badge bg-danger">Rejected</span></td>
                          </tr>
                          <tr>
                            <th scope="row"><a href="#">#2644</a></th>
                            <td>Raheem Lehner</td>
                            <td><a href="#" class="text-primary">Sunt similique distinctio</a></td>
                            <td>$165</td>
                            <td><span class="badge bg-success">Approved</span></td>
                          </tr>
                        </tbody>
                      </table>
    
                    </div>

                </div>
            </div>

            <!-- ========= informacion  =========-->
            <div class="col-5 p-0">
                <div class="card">
                    
                    <form class=" ps-3 pb-4 pt-4 col-12 ">
                        
                        <div class="row mb-3">
                          <label for="profileImage" class="col-md-4 col-lg-3 col-form-label">Peril Empresarial</label>
                          <div class="col-md-8 col-lg-9">
                            <img src="<?php echo e(asset('images/maps.png')); ?>" alt="Profile" style="width: 50px;">
                            <div class="pt-2">
                              <a href="#" class="btn btn-success btn-sm" title="Upload new profile image"><i class="bi bi-upload"></i></a>
                              <a href="#" class="btn btn-danger btn-sm" title="Remove my profile image"><i class="bi bi-trash"></i></a>
                            </div>
                          </div>
                        </div>
                        
                        <div class="row mb-3">
                          <label for="Nombre_E" class="col-md-4 col-lg-3 col-form-label">Nombre Completo</label>
                          <div class="col-md-8 col-lg-8">
                            <input name="Nombre_E" type="text" class="form-control" id="Nombre_E" placeholder="* Razón social">
                          </div>
                        </div>
                        
                        <div class="row mb-3">
                          <label for="about" class="col-md-4 col-lg-3 col-form-label">Descripción corporativa</label>
                          <div class="col-md-8 col-lg-8">
                            <textarea name="about" class="form-control" id="about" style="height: 100px" placeholder="Misión y Visión empresarial."></textarea>
                          </div>
                        </div>
                        
                        <div class="row mb-3">
                          <label for="Ciudad" class="col-md-4 col-lg-3 col-form-label">Ciudad</label>
                          <div class="col-md-8 col-lg-8">
                            <input name="Ciudad" type="text" class="form-control" id="Ciudad" placeholder="* Localidad">
                          </div>
                        </div>
                        
                        <div class="row mb-3">
                          <label for="Address" class="col-md-4 col-lg-3 col-form-label">Dirección</label>
                          <div class="col-md-8 col-lg-8">
                            <input name="address" type="text" class="form-control" id="Address" placeholder="* Localización">
                          </div>
                        </div>
                        
                        <div class="row mb-3">
                          <label for="Phone" class="col-md-4 col-lg-3 col-form-label">Número de teléfono</label>
                          <div class="col-md-8 col-lg-8">
                            <input name="phone" type="text" class="form-control" id="Phone" placeholder="* (602) 486 90 71">
                          </div>
                        </div>
                        
                        <div class="row mb-3">
                          <label for="Email" class="col-md-4 col-lg-3 col-form-label">Correo electronico</label>
                          <div class="col-md-8 col-lg-8">
                            <input name="email" type="email" class="form-control" id="Email" placeholder="ejemplo@gmail.com">
                          </div>
                        </div>
                        
                        <div class="row mb-3">
                          <label for="Facebook" class="col-md-4 col-lg-3 col-form-label">Perfil de Facebook</label>
                          <div class="col-md-8 col-lg-8">
                            <input name="facebook" type="text" class="form-control" id="Facebook" placeholder="https://facebook.com/#">
                          </div>
                        </div>
                        
                        <div class="row mb-3">
                          <label for="Instagram" class="col-md-4 col-lg-3 col-form-label">Perfil Instagram</label>
                          <div class="col-md-8 col-lg-8">
                            <input name="instagram" type="text" class="form-control" id="Instagram" placeholder="https://instagram.com/#">
                          </div>
                        </div>
                        
                        <div class="row mb-3">
                          <label for="Linkedin" class="col-md-4 col-lg-3 col-form-label">Whatsapp</label>
                          <div class="col-md-8 col-lg-8">
                            <input name="linkedin" type="text" class="form-control" id="Linkedin" placeholder="https://api.whatsapp.com/send?phone=573207203628&text=">
                          </div>
                        </div>
                        
                        <div class="text-center">
                          <button type="submit" class="btn btn-success btn-lg">Guardar Cambios</button>
                        </div>

                    </form> 
                    
                </div>
            </div>
        </div>
    
      </div>
    </section>

  </main><!-- End Conten -->


  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\xampp\htdocs\Inver-E\resources\views/usuarios.blade.php ENDPATH**/ ?>