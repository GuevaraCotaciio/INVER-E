<head>
    <title>Inver-E / Informes-Clientes</title>
</head>
    <!-- ======= Header ======= -->
    <?php echo $__env->make('Templates.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Header -->

    <!-- ======= Contendor Principal  ======= -->
    <main class="col-12 ps-1" style="background-color: #e8edf4;">

        <!-- Tirulos modulos-->
        <div class="pagetitle ps-4">
          <h1>Informes</h1>
          <nav>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
              <li class="breadcrumb-item"><a href="<?php echo e(route('informes.general')); ?>">Informes</a></li>
              <li class="breadcrumb-item active">Clientes</li>
            </ol>
          </nav>
        </div>

        <!-- ========= Reportes   ========= -->
        <div class="col-12">
            <div class="card">

              <div class="filter">
                <a class="icon" href="#" data-bs-toggle="dropdown" aria-expanded="false"><i class="bi bi-three-dots"></i></a>
                <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow" style="">
                  <li class="dropdown-header text-start">
                    <h6>Filter</h6>
                  </li>

                  <li><a class="dropdown-item" href="#">Today</a></li>
                  <li><a class="dropdown-item" href="#">This Month</a></li>
                  <li><a class="dropdown-item" href="#">This Year</a></li>
                </ul>
            </div>

            <div class="card-body">


                <div class="row col-12">
                    <div class="col-1"></div>
                    <h5 class="card-title col-8">* <span> información de clientes </span>    </h5>
                    <a href="#" class="btn btn-success btn-sm col-1 me-1">CSV <i class="bi bi-file-earmark-spreadsheet"></i></a>
                    <a href="<?php echo e(route('informe.pdf.clientes')); ?>" class="btn btn-danger btn-sm col-1 ms-1">PDF <i class="bi bi-file-earmark-pdf"></i></a>
                    <div class="col-1"></div>
                </div>
                <div class="row col-12 mt-2 mb-5 ms-0">
                    <div class="col-1"></div>
                    <div class="col-10 pe-0 ps-0">

                        <div class="table-responsive">
                            <table class="table" id="tablaclientes">
                                <thead>
                                    <tr>
                                      <th scope="col" class="border border-white table-primary">ID</th>
                                      <th scope="col" class="border border-white table-primary">Nombre</th>
                                      <th scope="col" class="border border-white table-primary">Documento</th>
                                      <th scope="col" class="border border-white table-primary">Genero</th>
                                      <th scope="col" class="border border-white table-primary">Edad</th>
                                      <th scope="col" class="border border-white table-primary">Teléfono</th>
                                      <th scope="col" class="border border-white table-primary">Ciudad</th>
                                      <th scope="col" class="border border-white table-primary">Dirección</th>
                                      <th scope="col" class="border border-white table-primary">E-mail</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($InfoClientes)<=0): ?>
                                        <tr>
                                        <td colspan="10" class="text-danger"> No hay registros para el nombre solicitado</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $InfoClientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infocliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="border-top"><?php echo e($infocliente->id); ?></td>
                                                <td class="border-top"><?php echo e($infocliente->nombre); ?> <?php echo e($infocliente->apellido); ?></td>
                                                <td class="border-top"><?php echo e($infocliente->documento); ?></td>
                                                <td class="border-top"><?php echo e($infocliente->genero); ?></td>
                                                <td class="border-top"><?php echo e($infocliente->edad); ?></td>
                                                <td class="border-top"><?php echo e($infocliente->telefono); ?></td>
                                                <td class="border-top"><?php echo e($infocliente->ciudad); ?></td>
                                                <td class="border-top"><?php echo e($infocliente->direccion); ?></td>
                                                <td class="border-top"><?php echo e($infocliente->email); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div><hr>


                <div class="row col-12">
                    <div class="col-1"></div>
                    <h5 class="card-title col-8">* <span> Cantidad pedidos por cliente  </span>    </h5>
                    <a href="#" class="btn btn-success btn-sm col-1 me-1">CSV <i class="bi bi-file-earmark-spreadsheet"></i></a>
                    <a href="#" class="btn btn-danger btn-sm col-1 ms-1">PDF <i class="bi bi-file-earmark-pdf"></i></a>
                    <div class="col-1"></div>
                </div>
                <div class="row col-12 mt-2 mb-5 ms-0">
                    <div class="col-1"></div>
                    <div class="col-10 pe-0 ps-0">

                        <div class="table-responsive">
                            <table class="table" id="tablaclientes">
                                <thead>
                                    <tr>
                                      <th scope="col" class="border border-white table-primary">ID</th>
                                      <th scope="col" class="border border-white table-primary">Nombre</th>
                                      <th scope="col" class="border border-white table-primary">Documento</th>
                                      <th scope="col" class="border border-white table-primary">Genero</th>
                                      <th scope="col" class="border border-white table-primary">Edad</th>
                                      <th scope="col" class="border border-white table-primary">Teléfono</th>
                                      <th scope="col" class="border border-white table-primary">Ciudad</th>
                                      <th scope="col" class="border border-white table-primary">Dirección</th>
                                      <th scope="col" class="border border-white table-primary">E-mail</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($PedidosClientes)<=0): ?>
                                        <tr>
                                        <td colspan="10" class="text-danger"> No hay registros para el nombre solicitado</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $PedidosClientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Pedidocliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="border-top"><?php echo e($Pedidocliente->id); ?></td>
                                                <td class="border-top"><?php echo e($Pedidocliente->nombre); ?> <?php echo e($Pedidocliente->apellido); ?></td>
                                                <td class="border-top"><?php echo e($Pedidocliente->documento); ?></td>
                                                <td class="border-top"><?php echo e($Pedidocliente->genero); ?></td>
                                                <td class="border-top"><?php echo e($Pedidocliente->edad); ?></td>
                                                <td class="border-top"><?php echo e($Pedidocliente->telefono); ?></td>
                                                <td class="border-top"><?php echo e($Pedidocliente->ciudad); ?></td>
                                                <td class="border-top"><?php echo e($Pedidocliente->direccion); ?></td>
                                                <td class="border-top"><?php echo e($Pedidocliente->email); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div><hr>


                <div class="row col-12">
                    <div class="col-1"></div>
                    <h5 class="card-title col-8">* <span> Tipo de producto por cliente </span>    </h5>
                    <a href="#" class="btn btn-success btn-sm col-1 me-1">CSV <i class="bi bi-file-earmark-spreadsheet"></i></a>
                    <a href="#" class="btn btn-danger btn-sm col-1 ms-1">PDF <i class="bi bi-file-earmark-pdf"></i></a>
                    <div class="col-1"></div>
                </div>
                <div class="row col-12 mt-2 mb-5 ms-0">
                    <div class="col-1"></div>
                    <div class="col-10 pe-0 ps-0">

                        <div class="table-responsive">
                            <table class="table" id="tablaclientes">
                                <thead>
                                    <tr>
                                      <th scope="col" class="border border-white table-primary">ID</th>
                                      <th scope="col" class="border border-white table-primary">Nombre</th>
                                      <th scope="col" class="border border-white table-primary">Documento</th>
                                      <th scope="col" class="border border-white table-primary">Genero</th>
                                      <th scope="col" class="border border-white table-primary">Edad</th>
                                      <th scope="col" class="border border-white table-primary">Teléfono</th>
                                      <th scope="col" class="border border-white table-primary">Ciudad</th>
                                      <th scope="col" class="border border-white table-primary">Dirección</th>
                                      <th scope="col" class="border border-white table-primary">E-mail</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($ProductoClientes)<=0): ?>
                                        <tr>
                                        <td colspan="10" class="text-danger"> No hay registros para el nombre solicitado</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $ProductoClientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productocliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="border-top"><?php echo e($productocliente->id); ?></td>
                                                <td class="border-top"><?php echo e($productocliente->nombre); ?> <?php echo e($productocliente->apellido); ?></td>
                                                <td class="border-top"><?php echo e($productocliente->documento); ?></td>
                                                <td class="border-top"><?php echo e($productocliente->genero); ?></td>
                                                <td class="border-top"><?php echo e($productocliente->edad); ?></td>
                                                <td class="border-top"><?php echo e($productocliente->telefono); ?></td>
                                                <td class="border-top"><?php echo e($productocliente->ciudad); ?></td>
                                                <td class="border-top"><?php echo e($productocliente->direccion); ?></td>
                                                <td class="border-top"><?php echo e($productocliente->email); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div><hr>

            </div>

        </div>

    </main><!-- End Conten -->

    <!-- ======= Footer ======= -->
    <?php echo $__env->make('Templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH C:\xampp\htdocs\Inver-E\resources\views/informes_clientes.blade.php ENDPATH**/ ?>