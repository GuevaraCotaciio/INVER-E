<head>
    <title>Inver-E / Clientes-crear</title>
</head>
<!-- ======= Header ======= -->
  <?php echo $__env->make('Templates.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Header -->

   <!-- ======= Content  ======= -->
  <main class="col-12 ps-1 pb-3" style="background-color: #e8edf4;">

    <!-- Tirulos modulos-->
    <div class="pagetitle ps-4">
      <h1>Clientes</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('clientes_general')); ?>">Clientes</a></li>
          <li class="breadcrumb-item active">Nuevo</li>
        </ol>
      </nav>
    </div>

    <div class="card ms-2 me-3">
      <div class="card-body m-4">

        <?php if(session()->has('fine')): ?>
        <div class="alert alert-success border-2 border-success"><?php echo e(session('fine')); ?></div>
        <?php elseif(session()->has('fail')): ?>
        <div class="alert alert-danger"><?php echo e(session('fail')); ?></div>
        <?php endif; ?>

        <h4 class="card-title mb-5">Crear nuevo Cliente</h4>

        <!-- ======== Formulario General ======== -->
        <form action="<?php echo e(route('clientes.save')); ?>" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>

            <div class="row col-lg-12 pe-0">

                <div class="col-lg-2">  <!-- foto del clinte -->

                    <div class="card p-0 border-0">
                        <img class="border-0" src="/public/default.png" alt="avatar" style="height: 130px;">
                    </div>

                    <div class="card-body ps-0">
                        <div class="input-group ">
                            <div class="custom-file me-2">
                                <input type="file" hidden class="custom-file-input" id="inputFile" name="archivo_cliente">
                                <a class="btn btn-success" title="Cargar nueva imagen" name="imagen">
                                    <label class="custom-file-label" for="inputFile"><i class="bi bi-upload"></i></label>
                                </a>

                            </div>
                            <button type="reset" class="btn btn-danger" title="Eliminar la imagen"><i class="bi bi-trash"></i></button>
                        </div>
                    </div>
                </div>

                <div class="col-lg-10 pe-0">

                    <div class="row mb-3 pe-0">
                      <label for="inputText" class="col-2 col-form-label">Nombres y apellidos</label>

                      <div class="col-10 pe-0">
                        <div class="input-group">
                          <input type="text" name="name" class="form-control form-control-lg" placeholder="* Nombres">
                          <input type="text" name="lastname" class="form-control form-control-lg" placeholder="* Apellidos">
                        </div>
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label for="inputText" class="col-2 col-form-label">Documento</label>

                      <div class="col-10 pe-0">
                        <div class="input-group">
                          <select class="form-select form-select-lg" name="tipoDoc">
                            <option selected>Seleccione el tipo documento</option>
                            <option value="CC">Cédula Ciudadania</option>
                            <option value="CE">Cédula Extrangeria</option>
                            <option value="TI">Tarjeta Identidad</option>
                          </select>
                          <input type="text" name="document" class="form-control form-control-lg" placeholder="* Número documento">
                        </div>
                      </div>
                    </div>

                    <div class="row mb-3">
                      <label class="col-sm-2 col-form-label">Genero</label>
                      <div class="col-sm-10 pe-0">
                        <select class="form-select form-select-lg" name="genero">
                          <option selected="">Selecciona el genero</option>
                          <option value="Hombre">Hombre</option>
                          <option value="Mujer">Mujer</option>
                        </select>
                      </div>
                    </div>

                </div>

            </div>


            <div class="row mb-3">
              <label for="fechaN" class="col-sm-2 col-form-label">Fecha Nacimiento</label>
              <div class="col-sm-10">
                <input class="form-control border p-2" type="date" id="fechaN" name="age"/>
              </div>
            </div>

            <div class="row mb-3">
              <label for="number" class="col-sm-2 col-form-label">Teléfono</label>
              <div class="col-sm-10">
                <input type="number" class="form-control form-control-lg" name="phone">
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputcity" class="col-sm-2 col-form-label">Ciudad</label>
              <div class="col-sm-10">
                <input type="text" class="form-control form-control-lg" name="city">
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputadress" class="col-sm-2 col-form-label">Dirección</label>
              <div class="col-sm-10">
                <input type="text"  class="form-control form-control-lg" name="adress">
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputEmail" class="col-sm-2 col-form-label">Correo Electronico</label>
              <div class="col-sm-10 ">
                <input type="email" class="form-control form-control-lg" name="email">
              </div>
            </div>

            <div class="row mb-3">
                <div class="form-check form-switch col-5 pt-2">
                  <input hidden class="form-check-input" type="radio" name="tipopersona" id="flexRadioDefault1" checked value="Cliente">
                </div>
            </div>

            <!-- Envio Formulario -->
            <div class="row  pt-3 pb-3 col-sm-12 ">
              <div class="col-4"></div>
              <div class="col-2 ">
                  <button type="submit" class="btn btn-success btn-lg ">Guardar Cliente</button>
              </div>
              <div class="col-2">
                  <a href="#!" class="btn btn-info btn-lg  muted">Cancelar</a>
              </div>
              <div class="col-4"></div>
            </div>

        </form>

      </div>
    </div>
  </main>


  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\Inver-E\resources\views/clientes_create.blade.php ENDPATH**/ ?>