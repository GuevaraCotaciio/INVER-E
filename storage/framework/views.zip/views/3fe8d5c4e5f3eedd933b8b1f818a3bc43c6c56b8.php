  <!-- ======= Header ======= -->
  <?php echo $__env->make('Templates.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Header -->

   <!-- ======= Content  ======= -->
  <main class="col-12 ps-1 pb-3" style="background-color: #e8edf4;">

    <!-- Tirulos modulos-->
    <div class="pagetitle ps-4">
      <h1>Clientes</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('clientes_general')); ?>">Clientes</a></li>
          <li class="breadcrumb-item active">Información</li>
        </ol>
      </nav>
    </div>

    <div class="card ms-2 me-3">
      <div class="card-body m-4">

        <div class="row col-12">
          <div class="col-9"><h4 class="card-title mb-5">Datos Personales.</h4></div>
          <div class="col-1"><a href="<?php echo e(route('clientes_general')); ?>" class="btn btn-info btn-lg">Atras</a></div>
          <div class="col-1"><a href="<?php echo e(route('clientes.update',$cliente->id)); ?>"class="btn btn-warning btn-lg">Editar</a></div>
          <div class="col-1"><a href="<?php echo e(route('clientes_general')); ?>"class="btn btn-danger btn-lg">Eliminar</a></div>
        </div>


        <div class="row col-12 p-0 m-0">



            <div class="row col-4  p-0 m-0 ">
                <div class="card">
                    <img src="<?php echo e(Storage::url($cliente->avatar)); ?>" alt="" width="150px">
                </div>

            </div>

            <div class="row col-8  p-0 ps-4 m-0">

                <table class="table table-borderless datatable" id="tablaclientes">
                    <thead>
                        <tr>
                          <th scope="col"> <h4>Nombre: </h4> </th>
                          <td> <h4><?php echo e($cliente->nombre); ?>  <?php echo e($cliente->apellido); ?> </h4></td>
                        </tr>
                        <tr>
                          <th scope="col"><h3>Documento: </h3></th>
                          <td> <h5><?php echo e($cliente->tipo_documento); ?> : <?php echo e($cliente->documento); ?> </h5></td>
                        </tr>

                        <tr>
                          <th scope="col"><h3>Genero: </h3></th>
                          <td> <h5><?php echo e($cliente->genero); ?> </h5></td>
                        </tr>
                        <tr>
                          <th scope="col"><h3>Edad: </h3></th>
                          <td> <h5><?php echo e($cliente->edad); ?> </h5></td>
                        </tr>
                        <tr>
                          <th scope="col"><h3>Teléfono: </h3></th>
                          <td> <h5><?php echo e($cliente->telefono); ?> </h5></td>
                        </tr>
                        <tr>
                          <th scope="col"><h3>Ciudad: </h3></th>
                          <td> <h5><?php echo e($cliente->ciudad); ?> </h5></td>
                        </tr>
                        <tr>
                          <th scope="col"><h3>Dirección: </h3></th>
                          <td> <h5><?php echo e($cliente->direccion); ?> </h5></td>
                        </tr>
                        <tr>
                          <th scope="col"><h3>E-mail: </h3></th>
                          <td> <h5><?php echo e($cliente->email); ?>  </h5></td>
                        </tr>
                    </thead>
                </table>

            </div>


        </div>

        <!-- ======== Formulario General ======== -->
        <!-- <form action="<?php echo e(route('clientes.edit', $cliente)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
          <div class="row mb-3">
            <label for="inputText" class="col-2 col-form-label">Nombres y apellidos</label>

            <div class="col-10">
              <div class="input-group">
                <input type="text" name="Firstname" disabled class="form-control form-control-lg" placeholder="* Nombres" value="<?php echo e($cliente->nombre); ?>">
                <input type="text" name="Lastname" disabled class="form-control form-control-lg" placeholder="* Apellidos" value="<?php echo e($cliente->apellido); ?>">
              </div>
            </div>
          </div>

          <div class="row mb-3">
            <label for="inputText" class="col-2 col-form-label">Documento</label>

            <div class="col-10">
              <div class="input-group">
                <input type="text" name="document" disabled class="form-control form-control-lg" placeholder="* Número documento" value="<?php echo e($cliente->tipo_documento); ?>">
                <input type="text" name="document" disabled class="form-control form-control-lg" placeholder="* Número documento" value="<?php echo e($cliente->documento); ?>">
              </div>
            </div>
          </div>

          <div class="row mb-3">
            <label class="col-sm-2 col-form-label">Genero</label>
            <div class="col-sm-10">
            <input type="text" disabled class="form-control form-control-lg" name="age" value="<?php echo e($cliente->genero); ?>">
            </div>
          </div>

          <div class="row mb-3">
            <label for="number" class="col-sm-2 col-form-label">Edad</label>
            <div class="col-sm-10">
              <input type="number" disabled class="form-control form-control-lg" name="age" value="<?php echo e($cliente->edad); ?>">
            </div>
          </div>

          <div class="row mb-3">
            <label for="number" class="col-sm-2 col-form-label">Teléfono</label>
            <div class="col-sm-10">
              <input type="number" disabled class="form-control form-control-lg" name="phone" value="<?php echo e($cliente->telefono); ?>">
            </div>
          </div>

          <div class="row mb-3">
            <label for="inputcity" class="col-sm-2 col-form-label">Ciudad</label>
            <div class="col-sm-10">
              <input type="text" disabled class="form-control form-control-lg" name="city" value="<?php echo e($cliente->ciudad); ?>">
            </div>
          </div>

          <div class="row mb-3">
            <label for="inputadress" class="col-sm-2 col-form-label">Dirección</label>
            <div class="col-sm-10">
              <input type="text"  disabled class="form-control form-control-lg" name="adress" value="<?php echo e($cliente->direccion); ?>">
            </div>
          </div>

          <div class="row mb-3">
            <label for="inputEmail" class="col-sm-2 col-form-label">Correo Electronico</label>
            <div class="col-sm-10 ">
              <input type="email" disabled class="form-control form-control-lg" name="email" value="<?php echo e($cliente->email); ?>">
            </div>
          </div>

          <div class="row mb-3">
            <label for="tipopersona" class="col-sm-2 col-form-label">Tipo de Persona</label>

            <div class=" row col-sm-10 ps-4">

              <div class="form-check form-switch col-5 pt-2">
                <input class="form-check-input" type="radio" name="tipopersona" id="flexRadioDefault1" checked value="Cliente">
                <label class="form-check-label" for="flexRadioDefault1">
                  Cliente
                </label>
              </div>

            </div>
          </div>




        </form> -->


      </div>
    </div>
  </main>


  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\Inver-E\resources\views/clientes_option.blade.php ENDPATH**/ ?>