<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(public_path('css/app.css')); ?>" type="text/css">
    <title>Inver-E / Reportes</title>
</head>
<body>


    <!-- ======= Contendor Principal  ======= -->
    <main class="col-12 ps-1" style="background-color: #ffffff;">

        <table class="table" id="tablaclientes">
            <thead>
                <tr>
                  <th scope="col" class="border border-white table-primary">ID</th>
                  <th scope="col" class="border border-white table-primary">Nombre</th>
                  <th scope="col" class="border border-white table-primary">Documento</th>
                  <th scope="col" class="border border-white table-primary">Genero</th>
                  <th scope="col" class="border border-white table-primary">Edad</th>
                  <th scope="col" class="border border-white table-primary">Teléfono</th>
                  <th scope="col" class="border border-white table-primary">Ciudad</th>
                  <th scope="col" class="border border-white table-primary">Dirección</th>
                  <th scope="col" class="border border-white table-primary">E-mail</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($listClientes)<=0): ?>
                  <tr>
                    <td colspan="10" class="text-danger"> No hay registros para el nombre solicitado</td>
                  </tr>
                <?php else: ?>
                  <?php $__currentLoopData = $listClientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clientes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="border-top"><?php echo e($clientes->id); ?></td>
                      <td class="border-top"><?php echo e($clientes->nombre); ?> <?php echo e($clientes->apellido); ?></td>
                      <td class="border-top"><?php echo e($clientes->documento); ?></td>
                      <td class="border-top"><?php echo e($clientes->genero); ?></td>
                      <td class="border-top"><?php echo e($clientes->edad); ?></td>
                      <td class="border-top"><?php echo e($clientes->telefono); ?></td>
                      <td class="border-top"><?php echo e($clientes->ciudad); ?></td>
                      <td class="border-top"><?php echo e($clientes->direccion); ?></td>
                      <td class="border-top"><?php echo e($clientes->email); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </tbody>
        </table>

    </main><!-- End Conten -->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Inver-E\resources\views/InformesPDF/informe_cliente_general.blade.php ENDPATH**/ ?>