<head>
    <title>Inver-E / Usuarios-Información</title>
</head>

<!-- ======= Header ======= -->
  <?php echo $__env->make('Templates.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- End Header -->

   <!-- ======= Content  ======= -->
  <main class="col-12 ps-1 pb-3" style="background-color: #e8edf4;">

    <!-- Tirulos modulos-->
    <div class="pagetitle ps-4">
      <h1>Usuarios</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
          <li class="breadcrumb-item"><a href="<?php echo e(route('usuarios.general')); ?>">Usuarios</a></li>
          <li class="breadcrumb-item active">Información</li>
        </ol>
      </nav>
    </div>

    <div class="card ms-2 me-3">
      <div class="card-body m-4">

        <div class="row col-12">
          <div class="col-9"><h4 class="card-title mb-5">Datos Personales.</h4></div>
          <div class="col-1"><a href="<?php echo e(route('usuarios.general')); ?>" class="btn btn-info btn-lg">Atras</a></div>
          <div class="col-1"><a href="<?php echo e(route('usuarios.update', $usuario->id)); ?>"class="btn btn-warning btn-lg">Editar</a></div>
          <div class="col-1"><a href="<?php echo e(route('usuarios.general')); ?>"class="btn btn-danger btn-lg">Eliminar</a></div>
        </div>


        <div class="row col-12 p-0 m-0">


            <div class="row col-4  p-0 m-0 ">
                <div class="card">
                    <img src="<?php echo e(Storage::url($usuario->avatar)); ?>" alt="" width="150px">
                </div>

            </div>

            <div class="row col-8  p-0 ps-4 m-0">
              <table class="table table-borderless datatable" id="tablaclientes">
                <thead>
                    <tr>
                        <th scope="col"><h3>Usuario: </h3></th>
                        <td> <h5><?php echo e($usuario->nombre); ?>  </h5></td>
                    </tr>
                    <tr>
                        <th scope="col"><h3>E-mail: </h3><hr></th>
                        <td> <h5><?php echo e($usuario->email); ?>  </h5><hr></td>
                    </tr>

                    <tr>
                      <th scope="col"> <h4>Nombre: </h4> </th>
                      <td> <h4><?php echo e($usuario->nombre); ?>  <?php echo e($usuario->apellido); ?> </h4></td>
                    </tr>
                    <tr>
                      <th scope="col"><h3>Documento: </h3></th>
                      <td> <h5><?php echo e($usuario->tipo_documento); ?> : <?php echo e($usuario->documento); ?> </h5></td>
                    </tr>
                    <tr>
                      <th scope="col"><h3>Genero: </h3></th>
                      <td> <h5><?php echo e($usuario->genero); ?> </h5></td>
                    </tr>
                    <tr>
                      <th scope="col"><h3>Edad: </h3></th>
                      <td> <h5><?php echo e($usuario->edad); ?> </h5></td>
                    </tr>
                    <tr>
                      <th scope="col"><h3>Teléfono: </h3></th>
                      <td> <h5><?php echo e($usuario->telefono); ?> </h5></td>
                    </tr>
                    <tr>
                      <th scope="col"><h3>Ciudad: </h3></th>
                      <td> <h5><?php echo e($usuario->ciudad); ?> </h5></td>
                    </tr>
                    <tr>
                      <th scope="col"><h3>Dirección: </h3></th>
                      <td> <h5><?php echo e($usuario->direccion); ?> </h5></td>
                    </tr>

                </thead>
                </table>

            </div>

            <div class="row col-6  p-0 ps-4 m-0">
              <h1></h1>
            </div>


        </div>
      </div>
    </div>
  </main>


  <!-- ======= Footer ======= -->
  <?php echo $__env->make('Templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\Inver-E\resources\views/usuarios_option.blade.php ENDPATH**/ ?>